class Employee {
  String _name;
  double _salary;
  String _dt;
  Employee(this._name, this._salary, this._dt);

  String get name => _name;

  set name(String value) {
    _name = value;
  }

  Map<String, dynamic> empObjecttoMap() {
    return {'name': name, 'salary': salary, 'dt': dt};
  }

  @override
  String toString() {
    return 'Employee{_name: $_name, _salary: $_salary, _dt: $_dt}';
  }

  double get salary => _salary;

  set salary(double value) {
    _salary = value;
  }

  String get dt => _dt;

  set dt(String value) {
    _dt = value;
  }
}
