import './employee.dart';
import '../utils/db.dart';

class EmployeeOperations {
  static Future<List> getEmps() async {
    List<Employee> empList = [];
    List<Map<String, dynamic>> list = await Db.query();
    print("Get All Emps ");

    print("Data Rec is ###::::: $list");
    list.forEach((map) {
      empList.add(Employee(map['name'], map['salary'], map['dt']));
    });
    Future<List<Employee>> future = Future(() {
      return empList;
    });
    return future;
  }

  static Future<String> addEmp(Employee empObject) async {
    int result = await Db.insert(empObject);
    print("::: Result is $result");
    Future<String> future = Future(() {
      if (result > 0) {
        return "Record Added";
      } else {
        return "Not Added";
      }
    });
    return future;
  }
}
