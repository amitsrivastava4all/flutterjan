import 'package:flutter/material.dart';

showAlertBox(context, message) {
  return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(message),
          actions: <Widget>[
            FlatButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Ok', style: TextStyle(fontSize: 30)),
            )
          ],
        );
      });
}
