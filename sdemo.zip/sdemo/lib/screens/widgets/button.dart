import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  Function _function;
  String _text;
  Button(Function function, String txt) {
    this._function = function;
    this._text = txt;
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(5),
      child: RaisedButton(
        color: Colors.lightBlueAccent,
        onPressed: _function,
        child: Text(
          _text,
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
