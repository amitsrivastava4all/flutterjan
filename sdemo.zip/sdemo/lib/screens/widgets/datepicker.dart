import 'package:flutter/material.dart';

class DatePicker extends StatelessWidget {
  Function _fn;
  DatePicker(this._fn);
  DateTime selectedDate = DateTime.now();
  _dp(BuildContext context) async {
    selectedDate = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2010),
        lastDate: DateTime(2030));
    _fn(selectedDate.toLocal());
    print("SEL Date is $selectedDate");
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: FlatButton(
        onPressed: () {
          _dp(context);
          print("Selected Date is $selectedDate");
        },
        child: Text(
          'Select Date',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
