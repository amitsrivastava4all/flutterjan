import 'package:flutter/material.dart';

class BTextBox extends StatelessWidget {
  String hint;
  TextEditingController tc;
  BTextBox(this.hint, this.tc);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(5),
      child: TextField(
        controller: tc,
        decoration: InputDecoration(
            hintText: 'Type ${this.hint} Here', border: OutlineInputBorder()),
      ),
    );
  }
}
