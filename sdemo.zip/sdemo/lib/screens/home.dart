import 'package:flutter/material.dart';

import './widgets/button.dart';
import './widgets/datepicker.dart';
import './widgets/textbox.dart';
import '../model/employee.dart';
import '../model/employeeoperation.dart';
import '../screens/list.dart';
import '../screens/widgets/alert.dart';
import '../utils/db.dart';
import '../utils/format.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController _name = TextEditingController();

  TextEditingController _salary = TextEditingController();
  String dt;
  String message;

  _getDate(dateValue) {
    setState(() {
      dt = Format.dateFormatting(dateValue);
    });
  }

  _add() {
    Employee emp = Employee(_name.text, double.parse(_salary.text), dt);
    print("Add Called $emp");
    EmployeeOperations.addEmp(emp).then((message) {
      setState(() {
        this.message = message;
        print("Record " + this.message);
        showAlertBox(context, this.message);
      });
    }).catchError((err) {
      print("error is $err");
    });
  }

  _clear() {}

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Db.init();
  }

  goToList() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ListScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sqlite Demo'),
        actions: <Widget>[
          IconButton(
            onPressed: () {
              goToList();
            },
            icon: Icon(
              Icons.assignment,
              color: Colors.yellow,
              size: 30,
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          child: (Column(
            children: <Widget>[
              BTextBox('Name', _name),
              BTextBox('Salary', _salary),
              Text('${dt ?? ''}'),
              DatePicker(_getDate),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Button(_add, "Add"),
                  Button(_clear, "Clear"),
                ],
              )
            ],
          )),
        ),
      ),
    );
  }
}
