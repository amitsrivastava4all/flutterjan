import 'package:flutter/material.dart';

import '../model/employeeoperation.dart';

class ListScreen extends StatefulWidget {
  @override
  _ListScreenState createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    EmployeeOperations.getEmps();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List of Records'),
      ),
      body: Container(
        child: FutureBuilder(
          builder: (context, asycSnapShot) {
            print("Snap Shot is $asycSnapShot");
            if (asycSnapShot.data == null) {
              return Container(
                  child: Center(
                child: Text(
                  'Loading.....',
                  style: TextStyle(fontSize: 30),
                ),
              ));
            }
            return ListView.builder(
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(asycSnapShot.data[index].name),
                  );
                },
                itemCount: asycSnapShot.data.length);
          },
          future: EmployeeOperations.getEmps(),
        ),
      ),
    );
  }
}
