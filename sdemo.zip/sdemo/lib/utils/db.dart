import 'package:sqflite/sqflite.dart';

import '../model/employee.dart';

class Db {
  static int get _version => 1;
  static Database _db;
  static init() async {
    try {
      String _path = await getDatabasesPath() + 'employee';
      _db = await openDatabase(_path,
          version: _version, onCreate: createEmployeeTable);
    } catch (e) {
      print("Exception During Init $e");
    }
  }

  static void createEmployeeTable(Database db, int version) async =>
      await db.execute(
          'CREATE TABLE emps (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL , name STRING, salary DOUBLE, dt STRING)');

  static Future<int> insert(Employee emp) async => await _db.insert(
        "emps",
        emp.empObjecttoMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

  static Future<List<Map<String, dynamic>>> query() async => _db.query("emps");

  static Future<int> update(String table, Employee model) async =>
      await _db.update(table, model.empObjecttoMap(),
          where: 'id = ?', whereArgs: [model]);

  static Future<int> delete(String table, Employee model) async =>
      await _db.delete(table, where: 'id = ?', whereArgs: [model]);
}
