import 'package:intl/intl.dart';
class Format {
  static String dateFormatting(DateTime dt) {
    var formatter = new DateFormat('dd-MM-yyyy');
    String formatted = formatter.format(dt);
    return formatted;
  }

  static String numberFormat(double val) {}
}
