Future<List<String>> getNames() {
  // DB + Network + file
//  Future<List<String>> l = Future(() {
//    List<String> l = ["Hello", "Hi", "Ok"];
//    return l;
//  });
  Future<List<String>> f = Future.delayed(Duration(seconds: 2), () {
    print("I am call after 2 sec");
    //return giveNames();
  });
  return f;
}

giveNames() {
  List<String> l = ["Hello", "Hi", "Ok"];
  return l;
}
